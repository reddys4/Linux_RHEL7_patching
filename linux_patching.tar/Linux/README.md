# DC Patching Procedures

## Prerequisites

* [Install Ansible on OSX](https://valdhaus.co/writings/ansible-mac-osx/)

```
brew install ansible
```

* Setup Pip

```bash
# ~/.pip/pip.conf
[global]
trusted-host = pypi.python.org
               pypi.org
               files.pythonhosted.org
```

* Install required Python packages
```bash
/usr/local/Cellar/ansible/$(ansible --version | grep "^ansible"|cut -f2 -d' ')/libexec/bin/pip3 install hvac iso8601 PyVmomi
```

* Add required environment variables
```bash
# ~/.profile
export OBJC_DISABLE_INITIALIZE_FORK_SAFETY=YES
```

## Generate servers inventory

```bash
# To patch managed test, switch to that environment

dc_test
cd ~/git/dc_patching
git pull
bash ./inventory_generator.sh
```

Your environment-specific server inventories will appear in the environment-specific subdirectory

---

## Update VM templates

**Unlike most Ansible steps, this is run exclusively from your laptop for all environments**

```bash
dc_test
cd ~/git/dc_patching

# manually create the tunnel for Hashicorp vault lookups
tunnel pdl11jmphst102-m.bby 8200 8201

# connect to vSphere
vc_tunnel

# export your vault token; plugin hashi_vault requires this be an environment variable
export VAULT_TOKEN=$(yq r ~/.dcc/dcc.yaml dcc.vault.token)

# update the templates
ansible-playbook playbooks/vsphere_template_update.yml -i ${AWS_ENV}/vsphere_templates

unset VAULT_TOKEN
```

---

## Patching all hosts

First part of below commands will do the patching for all the servers.
To run patching for individual inventory then run second part, will do patching for servers in respective inventory file.

```bash
cd ~/git/dc_patching
for inventory_file in `find $AWS_ENV -type f -depth 1`; do
  ansible-playbook playbooks/patching.yml -i $inventory_file
done

OR

cd ~/git/dc_patching
ansible-playbook playbooks/patching.yml -i $AWS_ENV/jboss
ansible-playbook playbooks/patching.yml -i $AWS_ENV/101_hosts
ansible-playbook playbooks/patching.yml -i $AWS_ENV/web_host_1
```

---

#### Notify [ASM](mailto:ASMSIM@bestbuy.com), [RST](mailto:RST@bestbuy.com), and ASM about pending patching activities (Server reboot, Tomcat restart)

---

## Post patching/Reboot activites.

### Handle app/agg hosts

**Repeat for 101\_hosts - 104\_hosts**

```bash
cd ~/git/dc_patching
ansible-playbook playbooks/reboot.yml -i ${AWS_ENV}/101_hosts -e patching=true
ansible-playbook playbooks/reboot.yml -i ${AWS_ENV}/102_hosts -e patching=true
.
.
```

---

### Jboss

Perform rolling reboot for all ATG servers:

```bash
ansible-playbook playbooks/rolling_reboot_atg.yml -i ./${AWS_ENV}/jboss -l dataapi -e patching=true
```

Upgrade Java sequentially on all ATG servers:
*Note: much like generic tomcat, you must set the preferred JDK8 path in the approprite group_vars file*

```bash
ansible-playbook playbooks/java_upgrade_atg.yml -i ./${AWS_ENV}/jboss
```

---

### ATG Lock Servers

* These can be patched as normal, but you MUST contact ASM for help rebooting; they can only be rebooted one at a time
* Post the following message in Hipchat's "::Ops - Operations::" room:
> @asm rebooting pdl11lckatg101; please watch for confirmation on 102
* Once they confirm, you can proceed
* Reboot pdl11lckatg101, and wait for ASM to confirm that:
  * pdl11lckatg102 has became primary, and
  * pdl11lckatg101 joined as secondary
* You can then reboot pdl11lckatg102
  * confirm with ASM that pdl11lckatg102 joined as secondary

---

### Apigee servers

Perform a rolling reboot on all Apigee servers

```bash
cd ~/git/dc_patching
ansible-playbook playbooks/rolling_reboot_apigee.yml -i ./${AWS_ENV}/apigee -e patching=true
```

Upgrade Java sequentially on all Apigee servers:
*Note: much like generic tomcat, you must set the preferred JDK8 path in the approprite group_vars file*

```bash
ansible-playbook playbooks/java_upgrade_apigee.yml -i ./${AWS_ENV}/apigee
```

---

### Kafka servers

Perform a rolling reboot on a Kafka cluster

```bash
cd ~/git/dc_patching
ansible-playbook playbooks/rolling_reboot_kafka.yml -i ./${AWS_ENV}/kafka -e patching=true
```

---

### Zookeeper servers

Perform a rolling reboot on a Zookeeper cluster

```bash
cd ~/git/dc_patching
ansible-playbook playbooks/rolling_reboot_zookeeper.yml -i ./${AWS_ENV}/zookeeper -e patching=true
```

---

### RabbitMQ Hosts

Perform a rolling reboot on RabbitMQ servers

```bash
cd ~/git/dc_patching
ansible-playbook playbooks/rolling_reboot_rabbit.yml -i ${AWS_ENV}/rabbitmq -e patching=true
```

---

### Web servers

```bash
cd ~/git/dc_patching
ansible-playbook playbooks/rolling_reboot_webservers.yml -i ${AWS_ENV}/web_host_1 -e patching=true
ansible-playbook playbooks/rolling_reboot_webservers.yml -i ${AWS_ENV}/web_host_2 -e patching=true
```

---

### Special Hosts

**Graphite: carbon doesn't start automatically**

```bash
/etc/init.d/carbon start
```

**Tealeaf Capture Servers - start services manually**

```bash
/usr/local/ctccap/bin/tealeaf status
/usr/local/ctccap/bin/tealeaf stop
/usr/local/ctccap/bin/tealeaf start
```

**Non-Cheffed Tomcat - start tomcat manually**

```bash
sudo su - tcadmin /opt/tomcat/bin/tomcat start all
```

**Old Search Servers**

```bash
# dlpafpsrcmrt101 & dlpafpsrcmrt101, dlpsrcsas10*, dlpsrcdas10* should only have one running instance of Tomcat at any time. dlpafpsrcmrt101 is usually started, and dlpafpsrcmrt102 does not have a running process.

sudo su - sptadm
cd /opt/tomcat/servers
tcadmin start all
```

**OOB Servers**

```bash
# Bloomington: pdl11od2ap001-m.bby and pdl11od2ap002-m.bby via pdl11jmphst102
# Denver     : 10.14.20.9 (pdl12od2ap001) and 10.14.20.10 (pdl12od2ap002) via hlrjmphst03
# Restart ODSEE:

sudo /opt/oracle/dsee7/bin/dsadm start /opt/oracle/dsee7/slapd-enterprise/

# Run command netstat -anpl | grep 636 ensure LDAP services are established connections.
```

**Consul Servers**

We use Consul as the backing store for our Vault instance. You shouldn't need to use this section, as with three nodes we can maintain cluster quorum as long as only one server reboots at any given time. However, should you lose 2+ nodes, you'll need these instructions to get the Consul cluster back up.

```bash
# pdl11jmphst102-m/pdl11jmphst103-m/pdl11chfapp101-m

# list raft status
consul operator raft -list-peers

# list cluster status
consul members

####
# Unseal the vault:
/root/unseal.sh

# If it says no cluster members:
service consul stop # on pdl11jmphst102-m, pdl11jmphst103-m, and pdl11chfapp101-m

# edit /var/lib/consul/raft/peers.json on each box and make it look like:

[
  "IP-1:8300",
  "IP-2:8300",
  "IP-3:8300"
]

# set 'bootstrap = true' on pdl11jmphst102-m and start consul
service consul start

# on pdl11jmphst103-m and pdl11chfapp101-m:
consul join pdl11jmphst102-m
```

---

## Double-check patching

**Repeat this step for all inventory files**

```bash
cd ~/git/dc_patching
for inventory_file in `find $AWS_ENV -type f -depth 1`; do
  ansible-playbook playbooks/check_patching.yml -i $inventory_file -e patching=true
done
```

Note any failed servers, and remediate manually

**Some helpful knife searches to validate patching:**

###### Validate Kernel Version
```bash
knife search 'platform_version 6.9 NOT kernel_release:2.6.32-696.23.1*' -a name -a kernel.release -a uptime
knife search 'platform_version 7.4 NOT kernel_release:3.10.0-693.17.1*' -a name -a kernel.release -a uptime
```

###### Validate Tomcat Version
```bash
knife search node 'recipes:dc_tomcat\:\:default NOT packages_apache-tomcat_version:7.0.85 NOT name:*wflapp*' -a name -a packages.apache-tomcat.version -a run_list
knife search node 'recipes:dc-generic-tomcat-role\:\:default NOT packages_apache-tomcat_version:8.0.50' -a name -a packages.apache-tomcat.version -a run_list
```

---

## Update Java/Tomcat

This step assumes:

* you've updated dc-uber-rhel-role with new versions of Tomcat and Java,
* done a role-sync on all ```depends 'dc_tomcat'``` and ```depends 'tomcat'``` role-cookbooks

#### Generic Tomcat

Generic Tomcat hosts are updated via Ansible.

You can either:

* accept the default versions of Tomcat 8 and Tomcat 9 in the ```tomcat``` cookbook, or
* Pin the preferred version in ```dc-generic-tomcat-role```

```ruby
# tomcat
node.override['tomcat']['version_9'] = '9.0.16'
```

Assuming we're targetting managed test in this case, update ```dc_test/group_vars/all``` with the appropriate Tomcat versions:

```yaml
tomcat8_preferred_version: '8.0.53'
tomcat9_preferred_version: '9.0.16'
```

Do role updates for any generic-tomcat wrapper cookbooks:

```bash
# role-update dependent role cookbooks
pushd ~/git/chef/dc-roles
pushd dc-generic-tomcat-role
git checkout master
popd

for role in $(grep -r "depends 'dc-generic-tomcat" */metadata.rb | cut -f1 -d'/'); do
  pushd $role 1>/dev/null 2>&1
  sync.rb -s -c $role
  bupn dc
  popd 1>/dev/null 2>&1
done

popd
```

Perform the upgrade on the appropriate jumphost:

```bash
# Pick your environment
ENV="dc_test"
SERIES=104
ansible-playbook playbooks/tomcat_upgrade.yml -i ${ENV}/${SERIES}_generic_tomcat
ansible all -i ${ENV}/${SERIES}_generic_tomcat -a "/opt/deployasaurus/heartbeat on" -u $(whoami) -f 10 --become --become-user tcadmin
# repeat for 103, 102, 101
```

---

## Update NodeJS

* this step assumes:
  * that NodeJS has had updates. https://nodejs.org/en/ shows what the latest LTS is.
  * you've updated the nodejs site-cookbok version metadata
  * you've updated dc-generic-nodejs-role with new versions of NodeJS and change the locked version


Assuming we're targetting managed test in this case, update ```dc_test/group_vars/all``` with the appropriate Node versions:

```yaml
nodejs_preferred_version:  '10.16.3'
```

Perform the upgrade on the appropriate jumphost:

```bash
# Pick your environment
ENV="dc_test"
SERIES=104
ansible-playbook playbooks/nodejs_upgrade.yml -i ${ENV}/${SERIES}_generic_nodejs
ansible all -i ${ENV}/${SERIES}_generic_nodejs -a "/opt/deployasaurus/heartbeat on" -u $(whoami) -f 10 --become --become-user tcadmin
```

---

## Update VM Tool for RHEL6 Servers

**Unlike most Ansible steps, this is run exclusively from your laptop for all environments**

```bash
dc_test
cd ~/git/dc_patching

# manually create the tunnel for Hashicorp vault lookups
tunnel pdl11jmphst102-m.bby 8200 8201

# connect to vSphere
vc_tunnel

# export your vault token; plugin hashi_vault requires this be an environment variable
export VAULT_TOKEN=$(yq r ~/.dcc/dcc.yaml dcc.vault.token)

# update the VMware tool
ansible-playbook playbooks/vmware_tool_update.yml -i ${AWS_ENV}/vmtool_upgrade.txt

unset VAULT_TOKEN
```

**Some useful knife searches to validate VM Tool Update:**

###### Validate VM tool update
```bash
knife search node 'platform_version:6* AND dmi_system_manufacturer:VMware* NOT vmware_upgrade:VMware Tools are up-to-date*' -a name -a vmware.upgrade
```

## Rotate root passwords

```bash
# set passwords
for app in `knife node list | sed 's/[0-9]//g' | sed 's/-m$//g' | cut -c 4- | uniq | sort`; do setpasswd $app; done

# verify password 'last set' time updated
for app in `knife node list | sed 's/[0-9]//g' | sed 's/-m$//g' | cut -c 4- | uniq | sort`; do chkpasswdexp $app; done
```

---

## Check HP firmware

Check for quarterly Service Packs from the [HP SPP site](http://h17007.www1.hpe.com/us/en/enterprise/servers/products/service_pack/spp/index.aspx) and apply to the hosts during that quarter

---

## Check VMware Updates

Check for the [latest patches for ESXi](https://my.vmware.com/group/vmware/patch) and apply to the clusters over three weeks.

Apply to Test: Week 1
Apply to Denver: Week 2
Apply to Bloomington: Week 3

---

## Audit DC users

* Audit [Authorized Production Access List](https://code.bestbuy.com/wiki/display/IO/Authorized+Production+Access+List)
