#!/usr/bin/env ruby

require 'net/https'
require 'json'
require 'yaml'
require 'mixlib/shellout'
require 'optimist'
require 'erb'

module Inventory

  class Datacenter
    attr_accessor :uri, :http, :dc_servers, :dc_farms

    def initialize()
      @uri = URI('https://imr.monitoring.bestbuy.com')
      @http = Net::HTTP.new(@uri.host, @uri.port)
      @http.use_ssl = true
      @http.verify_mode = OpenSSL::SSL::VERIFY_NONE
      @dc_servers = {}
      @dc_farms = {}
    end

    def get_imr_token()
      token = nil
      if File.exist?(File.expand_path(ENV['HOME'] + '/.dcc/dcc.yaml'))
        dcc_config = YAML.load_file(ENV['HOME'] + '/.dcc/dcc.yaml')
        token = dcc_config['dcc']['imr']['token'] if !dcc_config['dcc']['imr'].nil?
        return token
      end
    end

    def get_hosts(app_json_data)
      host_list = []
      JSON.recurse_proc(JSON.parse(app_json_data)) do |obj|
        if obj.is_a?(Hash) && obj['hosts']
          obj['hosts'].each do |host|
            host.end_with?('-m.bby') ? host_list << host : host_list << host + '-m.bby'
          end
        end
      end
      return host_list
    end

    def get_application_details(app, env)
      uri.path = "/api/configuration/environments/#{env}/applications/#{app}"
      request = Net::HTTP::Get.new(uri)
      request['Authorization'] = "Bearer #{get_imr_token}"
      request.content_type = "application/json"
      response = http.request(request)
      applications = JSON.parse(response.body)
      case response.code
      when '200'
        JSON.recurse_proc(JSON.parse(response.body)) do |obj|
          if obj.is_a?(Hash) && obj.keys[0].eql?(app)
            return get_hosts(obj.to_json)
          end
        end
      end
    end

    def get_farms_list(app, env)
      uri.path = "/api/userdata/environments/#{env}/applications/#{app}/farms"
      farms = []
      request = Net::HTTP::Get.new(uri)
      request['Authorization'] = "Bearer #{get_imr_token}"
      request.content_type = "application/json"
      response = http.request(request)
      farms_data = JSON.parse(response.body)
      case response.code
      when '200'
        farms_data['items'].each do |item|
          farms << item['farm_name']
        end
      else
        #puts "not able to find the application with name '#{app}' #{response.code} -> #{response.message}"
      end
      return farms
    end


    def get_applications_list(env)
      uri.path = "/api/configuration/environments/#{env}/applications"
      request = Net::HTTP::Get.new(uri)
      request['Authorization'] = "Bearer #{get_imr_token}"
      request.content_type = "application/json"
      response = http.request(request)
      applications = JSON.parse(response.body)
      case response.code
      when '200'
        applications['items'].each do |item|
          app_name = item['configuration'].keys.first
          hosts = get_application_details(app_name, env)
          if !hosts.nil? && !hosts.empty?
            if app_name.eql?('sentinel-dc')
              dc_servers[app_name] = hosts.first.split(',').sort.flatten
            else
              dc_servers[app_name] = hosts.flatten.sort
            end
            dc_farms[app_name] = get_farms_list(app_name, env)
          end
        end
      else
        #puts "not able to find the application with name '#{app}' #{response.code} -> #{response.message}"
      end
    end

    def get_chef_servers(env)
      chef_servers = Mixlib::ShellOut.new("knife node list")
      chef_servers.run_command
      chef_apps = []
      chef_servers.stdout.split("\n").each do |server|
        name = server.split('-')[0]
        chef_app = name[5..-4] if !name.include?('local')
        chef_apps << chef_app if !chef_apps.include?(chef_app) && !chef_app.nil? && !chef_app.eql?("")
      end
      chef_app_servers = {}
      chef_apps.sort.each do |chef_app|
        chef_app_servers[chef_app] = []
        hosts = []
        chef_servers.stdout.split("\n").each do |server|
          name = server.split('-')[0]
          hosts << name + '-m.bby' if !name.include?('local') && name.include?(chef_app) && !env.eql?('qa1')
          hosts << name if !name.include?('local') && name.include?(chef_app) && env.eql?('qa1')
        end
        chef_app_servers[chef_app] = hosts.flatten.sort
      end
      chef_app_servers.keys.each do |chef_app|
        app_found = false
        begin
          dc_servers.each_key {|key| app_found = true if dc_servers[key].first.include?(chef_app) }
        rescue Exception => error
          #puts "exception occured #{error.message} for #{chef_app} for #{chef_app_servers[chef_app]}"
        end
        dc_servers[chef_app] = chef_app_servers[chef_app] if !app_found
      end

    end

    def get_tealeaf_servers(env)
      win_servers = Mixlib::ShellOut.new("dcc vault list | grep pdw11tlf | cut -d '/' -f 2")
      win_servers.run_command
      win_hosts = []
      win_servers.stdout.split("\n").each do |server|
        if !server.match('(^\w+)').nil?
          win_host = server.scan(/(^\w+)/).join('')
          win_hosts << win_host if !win_hosts.include?(win_host)
        end
      end
      dc_servers['tealeaf'] = win_hosts
    end

    def get_all_dc_servers(env)
      #get_applications_list(env) if !get_imr_token().nil?
      get_chef_servers(env)
      #get_tealeaf_servers(env)
      dc_farms.each_key {|dc_app| dc_farms[dc_app] = dc_farms[dc_app].join("\n")}
      return dc_servers
    end

  end

  # To collect command line options
  class CLI
    def self.cmd_options()
      p = Optimist::options do
        opt :list, "to list the inventory in json format", :type => :boolean, :default => true
        opt :host, "to list the vars associated with host names", :type => :string
      end
    end
  end

end

def process_inv_file(ansible_json_inventory)
#  inv_template = %{
#    <% ansible_json_inventory.keys.each do |app| %>
#[<%= app %>]
#      <% ansible_json_inventory[app]['hosts'].each do |host| %>
#<%= host %>
#      <% end %>
#    <% end %>
#  }
#  renderer = ERB.new(inv_template)
#  renderer.result(binding)
  ansible_json_inventory.keys.each do |app|
    puts '[' + app + ']'
    ansible_json_inventory[app]['hosts'].each do |host|
      puts host
    end
  end
end

#Main program starts from here.
cli_options = Inventory::CLI.cmd_options

env = 'prod' if ENV['AWS_ENV'].eql?('dc_prod')
env = 'dr' if ENV['AWS_ENV'].eql?('dc_dr')
env = 'stage' if ENV['AWS_ENV'].eql?('dc_stage')
env = 'test' if ENV['AWS_ENV'].eql?('dc_test')
env = 'qa1' if ENV['AWS_ENV'].eql?('dc_qa1')

dc_obj = Inventory::Datacenter.new()
dc_app_dict = dc_obj.get_all_dc_servers(env)
dc_farm_dict = dc_obj.dc_farms

ansible_json_inventory = {}

if cli_options[:list_given]
  dc_app_dict.keys.each do |dc_app|
    ansible_json_inventory[dc_app] = {}
    ansible_json_inventory[dc_app]['hosts'] = dc_app_dict[dc_app]
  end
  # process_inv_file(ansible_json_inventory)
  ansible_json_inventory['_meta'] = {}
  ansible_json_inventory['_meta']['hostvars'] = {}
  ansible_json_inventory['_meta']['all'] = {}
  ansible_json_inventory['_meta']['all']['children'] = []
  dc_app_dict.each_key {|app_name|  ansible_json_inventory['_meta']['all']['children'] << app_name}
  puts JSON.pretty_generate(JSON.parse(JSON.generate(ansible_json_inventory)))
end
