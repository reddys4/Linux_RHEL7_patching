#!/usr/bin/env ruby
require 'json'
require 'chef'
require 'pry'
require_relative './ssh'
require 'csv'

def self.get_nodes(environment)
  instances = []
  Chef::Config.from_file("#{ENV['HOME']}/.chef/knife.rb")
  config = Chef::Config
  config.client_key = "#{ENV['HOME']}/.chef/keys/#{ENV['AWS_ENV']}_user_key.pem"
  Chef::Node.list.each do |node, _server|
      instances << node
  end
  #instances = ['ptl11txnsrc101']
  instances.sort!
  instances
end

nodes = get_nodes(ENV['AWS_ENV'])
abort('No Results!') if nodes.empty?
if ENV['AWS_ENV'] != 'dc_qa1'
  nodes = nodes.map do |node|
    node.include?('-m') ? node.chomp('-m') : node
  end
  nodes = nodes.map do |node|
    node.include?('-new') ? node.chomp('-new') : node
  end
  nodes = nodes.reject { |c| c.include?('buildapp101') }
  nodes = nodes.reject { |c| c.include?('localhost') }
  nodes = nodes.reject { |c| c.include?('pdw') }
  nodes = nodes.reject { |c| c.include?('pdl11jmphst') }
  nodes = nodes.map { |node| "#{node}-m.bby" }
end
if ENV['AWS_ENV'] == 'dc_qa1'
  nodes = nodes.map do |node|
    !node.include?('.na.bestbuy.com') ? "#{node}.na.bestbuy.com" : node
  end
  nodes = nodes.reject { |c| c.include?('buildapp101') }
  nodes = nodes.reject { |c| c.include?('jenkins') }
end

command = 'rpm -qa --qf "%{NAME},%{VERSION}-%{RELEASE}.%{ARCH},%{INSTALLTIME:date}\n"'
Dir.chdir "#{ENV['HOME']}/git/dc_patching/patch-documentation/csv/"
CSV.open("patching-#{ENV['AWS_ENV']}.csv", "w+") do |csv|
  csv << ["Server Name", "Package", "Installed Version", "Installed Date"]
  nodes.each do |node|
    # TODO: better exception handling
    next if !node.match('ptl11duotest').nil?
    next if !node.match('ptl11jenkins').nil?
    rpmdb = Patch::Ssh.single_command(node, command)
    packages = rpmdb.split(/\r?\n/)
    packages.each do |package|
      value = package.split(',')
      csv << [ node, value[0], value[1], value[2] ]
    end
  end
end
