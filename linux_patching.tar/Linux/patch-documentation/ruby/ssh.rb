require 'net/ssh'
require 'net/ssh/proxy/command'
require 'yaml'
require 'rotp'
require 'net/ssh/gateway'
require 'rainbow'

module Patch
  #
  class Ssh

    def self.single_command(host, command, options = {})
      options[:environment] = ENV['AWS_ENV']
      result = ''
      exit_code = nil
      # Start SSH connection
      if options[:environment] == 'dc_qa1'
        options = {:verify_host_key => false}
        begin
          Net::SSH.start(host, ENV['CHEFUSER']) do |session|
            session.open_channel do |channel|

              channel.on_data do |ch, data|
                result += data.to_s
              end

              channel.request_pty do |ch, success|
                success ? ch.exec(command) : (puts "not able to become sudo user on '#{host}'".colorize(:red))
              end

              channel.on_request "exit-status" do |ch, data|
                exit_code = data.read_long
              end

            end
            session.loop
          end
        rescue Exception => error
          puts "error occured for host #{host} -> #{error.message} \n #{error.backtrace.join("\n")}"
          abort
        end
        return result.strip

      else
        token = get_token(options)
        jumpbox = get_jumphost(options)
        options = { :verify_host_key => false }
        ssh_options = { :password => token, :verify_host_key => false }
        begin
          gateway =
            if options[:environment] == 'dc_test'
              Net::SSH::Gateway.new(jumpbox, ENV['CHEFUSER'], options)
            else
              Net::SSH::Gateway.new(jumpbox, ENV['CHEFUSER'], ssh_options)
            end
          gateway.ssh(host, ENV['CHEFUSER']) do |session|
            session.open_channel do |channel|
              channel.on_data do |ch, data|
                result += data.to_s
              end

              channel.request_pty do |ch, success|
                success ? ch.exec(command) : (puts "not able to become sudo user on '#{host}'".colorize(:red))
              end

              channel.on_request "exit-status" do |ch, data|
                exit_code = data.read_long
              end

            end
            session.loop
          end
          gateway.shutdown! if gateway.active?
        rescue Exception => error
          puts "error occured for host #{host} -> #{error.message} \n #{error.backtrace.join("\n")}"
          abort
        end
      end
      result.strip
    end

    def self.get_token(options)
      env = options[:environment]
      env = env.split('_').last
      return if env.include?('qa1') || env.include?('test')
      c = YAML.load_file("#{ENV['HOME']}/.dcc/dcc.yaml")['dcc']['totp']

      return ROTP::TOTP.new(c[env]['key']).now unless c[env]['key'].empty?
    end

    def self.get_jumphost(options)
      env = options[:environment]
      env = env.split('_').last
      return if env == 'qa1'
      c = YAML.load_file("#{ENV['HOME']}/.dcc/dcc.yaml")['dcc']['jumpbox']
      return c[env] unless c[env].empty?
    end

    def self.print_data(host, data)
      @buffers ||= {}
      if leftover = @buffers[host]
        @buffers[host] = nil
        print_data(host, leftover + data)
      else
        if newline_index = data.index("\n")
          line = data.slice!(0...newline_index)
          data.slice!(0)
          print_line(host, line)
          print_data(host, data)
        else
          @buffers[host] = data
        end
      end
    end

    def self.print_line(host, data)
      puts Rainbow("#{host}: ").cyan + data
    end
  end
end
