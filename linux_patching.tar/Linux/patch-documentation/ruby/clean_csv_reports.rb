#!/usr/bin/env ruby
require 'fileutils'

Dir.chdir "#{ENV['HOME']}/git/dc_patching/patch-documentation/ruby/"
csvs = Dir.glob("../csv/*.csv").select{ |e| File.file? e }
html = Dir.glob("../report/**/*").select{ |e| File.file? e }

files = csvs + html
files.each do |file|
  if File.exists?(file)
    File.delete(file)
  end
end

dir = Dir.glob("../report/**/*").select{ |e| File.directory? e } 
dir.reverse.each do |dir|
  if File.exists?(dir)
    FileUtils.remove_dir(dir)
  end
end

if File.exists?('../report/.Rhistory')
  File.delete('../report/.Rhistory')
end
