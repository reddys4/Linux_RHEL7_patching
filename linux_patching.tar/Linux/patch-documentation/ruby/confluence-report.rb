#! /usr/bin/env ruby
require 'yaml'
require 'net/https'
require 'json'
require 'daru'
require 'gruff'
require 'pry'
require 'erb'
require 'ostruct'
require 'net/http/post/multipart'

# methods
# brew install imagemagick@6
# export PATH="/usr/local/opt/imagemagick@6/bin:$PATH"
# export LDFLAGS="-L/usr/local/opt/imagemagick@6/lib"
# export CPPFLAGS="-I/usr/local/opt/imagemagick@6/include"
# export PKG_CONFIG_PATH="/usr/local/opt/imagemagick@6/lib/pkgconfig"

module Confluence

  class Report
    attr_accessor :uri, :http, :username, :password

    def initialize()
      login_config = YAML.load_file("#{ENV['HOME']}/.stashconfig.yml")
      @uri = URI('https://code.bestbuy.com')
      @http = Net::HTTP.new(uri.host, uri.port)
      @http.use_ssl = true
      @http.verify_mode = OpenSSL::SSL::VERIFY_NONE
      @username = login_config['username']
      @password = login_config['password']
    end

    def get_patching_root_page_data(page_name)
      uri.path = '/wiki/rest/api/content'
      page_location = {
                        :spaceKey => 'Ops',
                        :title => page_name
                      }
      uri.query = URI.encode_www_form(page_location)
      request = Net::HTTP::Get.new(uri)
      request.basic_auth  "#{username}", "#{password}"
      request.content_type = "application/json"
      response = http.request(request)
      case response.code
      when '200'
        return JSON.parse(response.body)
      else
        abort("not able to get children page id -> #{response.message}")
      end
    end

    def get_child_pages(child_end_point)
      uri.path = "/wiki#{child_end_point}"
      uri.query = URI.encode_www_form({:expand => 'page'})
      request = Net::HTTP::Get.new(uri)
      request.basic_auth  "#{username}", "#{password}"
      request.content_type = "application/json"
      response = http.request(request)
      case response.code
      when '200'
        return JSON.parse(response.body)
      else
        abort("not able to get children page id -> #{response.message}")
      end
    end

    def get_report_page_root()
      report_page_child = nil
      ancestor_page_id = 0
      self.get_child_pages(self.get_patching_root_page_data('Patching - Prod')['results'].first['_expandable']['children'])['page']['results'].each do |result|
        if result['_links']['webui'].downcase.end_with?('patching')
          report_page_child = result['_expandable']['children']
          ancestor_page_id = result['id'] if result['_links']['webui'].downcase.end_with?('patching')
        end
      end
      return ancestor_page_id, report_page_child
    end

    def create_page(page_details)
      uri.path = "/wiki/rest/api/content"
      uri.query = URI.encode_www_form({})
      request = Net::HTTP::Post.new(uri)
      request.basic_auth  "#{username}", "#{password}"
      request.content_type = "application/json"
      request.body = JSON.pretty_generate(JSON.parse(page_details.to_json))
      response = http.request(request)
      case response.code
      when '200'
        puts "successfully created new page -> #{response.code}"
      else
        abort("not able to get children page id -> #{response.code} - #{response.body}")
      end
    end

    def add_attachement(landing_page_id, src_file_path)
      uri.path = "/wiki/rest/api/content/#{landing_page_id}/child/attachment"
      uri.query = URI.encode_www_form({})
      request = Net::HTTP::Post::Multipart.new uri, "file" => UploadIO.new(src_file_path, "image/jpeg", File.basename(src_file_path))
      request['X-Atlassian-Token'] = 'nocheck'
      request.basic_auth  "#{username}", "#{password}"
      response = http.request(request)
      case response.code
      when '200'
        puts "successfully added attachment -> #{response.code}"
      else
        abort("not able to add attachment -> #{response.code} - #{response.body}")
      end

    end

    def get_landing_page_id(report_page_child, ancestor_page_id)
      last_page_name = self.get_child_pages(report_page_child)['page']['results'].last['_links']['webui'].split('/').last
      if last_page_name.downcase.include?(Date.today.strftime("%B").downcase)
        new_summary_page = last_page_name
      else
        last_page_count = last_page_name.scan(/(^\d+)/)[0].join('')
        last_page_count.to_i/10 > 0 ? new_page_count = (last_page_count.to_i + 1).to_s : new_page_count = '0' + (last_page_count.to_i + 1).to_s
        new_summary_page = new_page_count + ' - ' + Date.today.strftime("%B") + ' patching summary'
        new_page_details = {
          type: "page",
          title: new_summary_page,
          space: {key: 'Ops'},
          ancestors:[
            {
              type:"page",
              id: ancestor_page_id
            }
          ]
        }
        self.create_page(new_page_details)
      end
      return self.get_child_pages(report_page_child)['page']['results'].last['id']
    end

    def create_pie_graph(data)
      g = Gruff::Pie.new
      g.show_values_as_labels = true
      g.title = "Patching Coverage By Count"
      data.each do |data|
        g.data(data[0], data[1])
      end

      # Default theme
      filename = "#{ENV['AWS_ENV']} - #{Date.today}.png"
      g.write("../report/#{filename}")
    end

    def create_new_report_page()

      ancestor_page_id = self.get_report_page_root[0]
      report_page_child = self.get_report_page_root[1]
      data_frame = nil
      if !report_page_child.nil?
        landing_page_id = get_landing_page_id(report_page_child, ancestor_page_id)

        now = Date.today
        oldest_date = (now - 30)

        Dir.chdir "#{ENV['HOME']}/git/dc_patching/patch-documentation/csv/"
        data_frame = Daru::DataFrame.from_csv("patching-#{ENV['AWS_ENV']}.csv")
        data_frame['Patched'] = data_frame['Installed Date'].map do |date|
          begin
            Date.parse(date) > oldest_date
          rescue Exception => error
            puts error.message
            next
          end
        end

        serverList = data_frame['Server Name'].uniq
        serverCount = data_frame['Server Name'].uniq.count
        patchedServers = data_frame.where(data_frame['Patched'].eq(true))['Server Name'].uniq
        unPatchedServers = data_frame.where(!data_frame['Server Name'].in(patchedServers))['Server Name'].uniq

        data = [
          ["Patched", patchedServers.count],
          ["Non-Patched", unPatchedServers.count],
        ]
        self.create_pie_graph(data)

        filename = "#{ENV['AWS_ENV']} - #{Date.today}.png"
        image_path = "#{ENV['HOME']}/git/dc_patching/patch-documentation/report/#{filename}"

        namespace = OpenStruct.new('serverCount': serverCount, 'UnPatchedServers': unPatchedServers, 'filename': filename)
        renderer = ERB.new(File.read('../ruby/confluence.erb'))

        page_source = renderer.result(namespace.instance_eval { binding })
        new_page_title = "#{ENV['AWS_ENV']} - #{Date.today}"
        new_page_details = {
          type:"page",
          title: new_page_title,
          body: {
            "storage": {
              "value": page_source,
              "representation": "storage"
              }
            },
          space: {key: 'Ops'},
          ancestors:[
            {
              type:"page",
              id: landing_page_id
            }
          ]
        }
        self.create_page(new_page_details)
        attachment_landing_pag_id = self.get_patching_root_page_data(new_page_title)['results'].first['id']
        self.add_attachement(attachment_landing_pag_id, image_path)
      end
    end
  end
end

conf_obj = Confluence::Report.new
conf_obj.create_new_report_page



#conf_obj.get_root_page['results'].each do |result|
#   puts JSON.pretty_generate(conf_obj.get_children())
#end
