#!/usr/bin/env ruby
require 'daru'
require 'gruff'
require 'pry'
require 'yaml'
require 'confluence/api/client'
require 'erb'
require 'ostruct'

# methods
# brew install imagemagick@6
# export PATH="/usr/local/opt/imagemagick@6/bin:$PATH"
# export LDFLAGS="-L/usr/local/opt/imagemagick@6/lib"
# export CPPFLAGS="-I/usr/local/opt/imagemagick@6/include"
# export PKG_CONFIG_PATH="/usr/local/opt/imagemagick@6/lib/pkgconfig"
def create_pie_graph(data)
  g = Gruff::Pie.new
  g.show_values_as_labels = true
  g.title = "Patching Coverage By Count"
  data.each do |data|
    g.data(data[0], data[1])
  end

  # Default theme
  filename = "patching-pie-#{ENV['AWS_ENV'].split('_').last}-#{Date.today}.png"
  g.write("../report/#{filename}")
end

# Variables
now = Date.today
oldest_date = (now - 60)

Dir.chdir "#{ENV['HOME']}/git/dc_patching/patch-documentation/csv/"
data_frame = Daru::DataFrame.from_csv("patching-#{ENV['AWS_ENV']}.csv")
data_frame['Patched'] = data_frame['Installed Date'].map do |date|
  Date.parse(date) > oldest_date
end

ServerList = data_frame['Server Name'].uniq
ServerCount = data_frame['Server Name'].uniq.count
PatchedServers = data_frame.where(data_frame['Patched'].eq(true))['Server Name'].uniq
UnPatchedServers = data_frame.where(!data_frame['Server Name'].in(PatchedServers))['Server Name'].uniq

data = [
  ["Patched", PatchedServers.count],
  ["Non-Patched", UnPatchedServers.count],
]
create_pie_graph(data)

# Get Confluence Creds
config = YAML.load_file("#{ENV['HOME']}/.stashconfig.yml")
url = 'https://code.bestbuy.com/'

# Publish
client = ::Confluence::Api::Client.new(config['username'], config['password'], url)
space = 'Ops'
patching_landing = '07 - September patching summary'
filename = "patching-pie-#{ENV['AWS_ENV'].split('_').last}-#{Date.today}.png"
image_path = "../report/#{filename}"

namespace = OpenStruct.new('serverCount': ServerCount, 'UnPatchedServers': UnPatchedServers, 'filename': filename)
renderer = ERB.new(File.read('../ruby/confluence.erb'))
page_source = renderer.result(namespace.instance_eval { binding })

page = client.get({spaceKey: space, title: patching_landing})[0]
new_page_details = {
  type:"page",
  title: "Patching Report - #{patching_landing} - #{Date.today}",
  body: {
    "storage": {
      "value": page_source,
      "representation": "storage"
      }
    },
  space: {key: space},
  ancestors:[
    {
      type:"page",
      id: page['id']
    }
  ]
}

create = client.create(new_page_details)
if create['statusCode'] == 400
  raise create['message']
else
  puts 'Page has been created.'
end

file = client.upload_file(create['id'], image_path)
if file['statusCode'] == 400
  raise file['message']
else
  puts 'Image has been uploaded.'
end
