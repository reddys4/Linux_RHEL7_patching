Patching Report
=====

A script bundle that performs the actions to create a CSV and reads the CSV for the purpose of data analysis for if patching has occurred on a node in 60 days.

## Usage

The scripts that are included in this tool connect to Chef Server and fetch all nodes in it.

It will iterate the hosts and connect via SSH and perform an `rpm -qa -qf ...`.
The output will be written to a CSV for all nodes.

Another Ruby script loads CSV and creates the following data:
- Total Servers List
- Total Servers Count
- Patched Servers
- Unpatched Servers

Once it has processed the CSV and created the required data, it will create a Confluence Page that will be able to shared through preferred medium.

## Execution

Change directory into patch-documentation
```
cd ~/git/dc_patching/patch-documentation/ruby
```
Execute:
```
bundle install
```

Execute:
```
dc_stage
./patch-csv.rb
```
^
This can take more than 30 minutes, but it really depends on how many nodes are being checked.
Stage runs this in about 25 minutes.
I will look at adding parallel SSH when/if this becomes a long-term and we do not

Execute:
```
./confluence-report.rb
```

## Prereqs
You should have Ruby installed through RVM as part of our Mac Set-up.

You will need to have imagemagick 6 installed, this can be done through the follwing:
```
brew install imagemagick@6
```

Once you have done that, you will need to add it to your profile.
```
export PATH="/usr/local/opt/imagemagick@6/bin:$PATH"
export LDFLAGS="-L/usr/local/opt/imagemagick@6/lib"
export CPPFLAGS="-I/usr/local/opt/imagemagick@6/include"
export PKG_CONFIG_PATH="/usr/local/opt/imagemagick@6/lib/pkgconfig"
```

You will need to have ~/.stashconfig.yml created with your most current Crowd credentials.
