#!/usr/bin/ruby
require 'openssl'
require 'digest'
require 'base64'
require 'yaml'
require 'colorize'
require 'logger'

def load_dcc_config()
    env = "prod"
    host = 'pdl11jmphst102-m.bby'
    config_dir = "#{Dir.home}/.dcc"
    config = nil
    if File.readable?("#{config_dir}/dcc.yaml")
        begin
          config = YAML.load_file("#{config_dir}/dcc.yaml")
        rescue Exception => e
          Logger.info "Something bad happened when trying to read #{File.join(Dir.home, '.dcc/dcc.yaml')}"
        end
    else
        puts "Needs to check"
    end
      #puts "#{config['dcc']['vault'][env][host]}"
      return config['dcc']['vault'][env][host]
 end

def get_vault_token()
      dcc_config = load_dcc_config()
      #puts "#{dcc_config}"
      return dcc_config['role_id'], dcc_config['token']
      #token = dcc_config['token']
end

def decrypt_token(secret, data)
          key = Digest::SHA256.digest(ENV['USER'] + secret)
          #puts "#{key}"
          raise "AES Decryption Error - Key size is incorrect" if key.nil? || key.size != 32
          data = Base64.decode64(data)
          #puts "#{data}"
          cipher = OpenSSL::Cipher::AES.new('256-CBC')
          cipher.decrypt
          cipher.key = key
          cipher.iv = data.slice!(0,16)
          cipher.padding = 0
          plain = cipher.update(data) + cipher.final
          #puts  "Test: #{plain}"
          return plain
end

secret, data  = get_vault_token
value = decrypt_token(secret, data)
#puts "export VAULT_TOKEN=#{value}"
puts "#{value}"
