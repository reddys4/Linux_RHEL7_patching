#!/bin/bash

black=$(tput setaf 0)
red=$(tput setaf 1)
green=$(tput setaf 2)
yellow=$(tput setaf 3)
blue=$(tput setaf 4)
magenta=$(tput setaf 5)
cyan=$(tput setaf 6)
white=$(tput setaf 7)
reset=$(tput sgr0)

echo "Generating inventory files for environment ${AWS_ENV}"
BASE_DIR="${HOME}/git/dc_patching/${AWS_ENV}"

mkdir -p ${BASE_DIR}

if [ ! -d $BASE_DIR ]; then
  echo "${BASE_DIR} does not exist - exiting"
  exit 1
fi

# delete previous inventory files, except those manually managed
find $BASE_DIR -type f -maxdepth 1 ! -name jboss ! -name vsphere_templates -delete

knife node list | grep -v oem | grep -v afpbch | grep -v olsdb | grep -v bdpols | \
  grep -v jmphst01 | grep -v jmphst02 | grep -v dnmapp | grep -v localhost | \
  grep -v afpwmq02 | grep -v buildapp | grep -v loghst01 | grep -v nflweb | \
  grep -v chfapp001 | grep -v txnsrc | \
  grep -v dataapi | grep -v pcmsatg | grep -v lckatg | grep -v afbch | grep -v cfbch | grep -v qdpatg >${BASE_DIR}/hosts.txt

echo "${green}** Outdated VMWare tools${reset}"
knife search node 'platform_version:6* AND dmi_system_manufacturer:VMware* NOT vmware_upgrade:VMware Tools are up-to-date*' \
-a name -a vmware.upgrade 2>/dev/null | grep name | grep -v build | cut -f2 -d':' | sed "s/^[ \t]*//" >${BASE_DIR}/vmtool_upgrade.txt

sed -i '' -e "s/$/-m.bby/" -e "s/-m-m/-m/" ${BASE_DIR}/hosts.txt

sed -i '' '/.*301/d' ${BASE_DIR}/hosts.txt
sed -i '' '/.*302/d' ${BASE_DIR}/hosts.txt
sed -i '' '/.*303/d' ${BASE_DIR}/hosts.txt
sed -i '' '/.*304/d' ${BASE_DIR}/hosts.txt
sed -i '' '/.*305/d' ${BASE_DIR}/hosts.txt

INVENTORY_FILE="sensu"
ROLE="dc-sensu-role"
echo "${green}** ${INVENTORY_FILE}${reset}"
echo "[${ROLE}]" >${BASE_DIR}/$INVENTORY_FILE
for HOST in $(knife search node "recipes:${ROLE}" -a name 2>/dev/null | grep name | cut -f2 -d':' | sed "s/^[ \t]*//" | sed "s/$/-m.bby/" | sed "s/-m-m/-m/" | sort) ;do
  echo $HOST >>${BASE_DIR}/${INVENTORY_FILE}
  echo $HOST | sed "s/-m.*//" | sed -i '' "/.*${HOST}.*/d" ${BASE_DIR}/hosts.txt
done
echo -e "\n[${ROLE}:vars]\nchef_role=${ROLE}" >>${BASE_DIR}/${INVENTORY_FILE}

INVENTORY_FILE="jumphosts"
rm -f ${BASE_DIR}/$INVENTORY_FILE
ROLE="dc-jumpbox-role"
echo "${green}** ${INVENTORY_FILE}${reset}"
for ROLE in dc-apigee-jumpbox-role dc-jumpbox-role dc-olsdb-jumpbox-role; do
  echo "[${ROLE}]" >>${BASE_DIR}/$INVENTORY_FILE
  for HOST in $(knife search node "recipes:${ROLE}" -a name 2>/dev/null | grep name | cut -f2 -d':' | sed "s/^[ \t]*//" | sed "s/$/-m.bby/" | sed "s/-m-m/-m/" | sort) ;do
    echo $HOST >>${BASE_DIR}/${INVENTORY_FILE}
    echo $HOST | sed "s/-m.*//" | sed -i '' "/.*${HOST}.*/d" ${BASE_DIR}/hosts.txt
  done
  echo -e "\n[${ROLE}:vars]\nchef_role=${ROLE}" >>${BASE_DIR}/${INVENTORY_FILE}
done

INVENTORY_FILE="chef_server"
ROLE="dc-chefserver-role"
echo "${green}** ${INVENTORY_FILE}${reset}"
echo "[${ROLE}]" >${BASE_DIR}/$INVENTORY_FILE
for HOST in $(knife search node "recipes:${ROLE}" -a name 2>/dev/null | grep name | cut -f2 -d':' | sed "s/^[ \t]*//" | sed "s/$/-m.bby/" | sed "s/-m-m/-m/" | sort) ;do
  echo $HOST >>${BASE_DIR}/${INVENTORY_FILE}
  echo $HOST | sed "s/-m.*//" | sed -i '' "/.*${HOST}.*/d" ${BASE_DIR}/hosts.txt
done
echo -e "\n[${ROLE}:vars]\nchef_role=${ROLE}" >>${BASE_DIR}/${INVENTORY_FILE}

INVENTORY_FILE="odsee"
ROLE="dc-odsee-role"
echo "${green}** ${INVENTORY_FILE}${reset}"
echo "[${ROLE}]" >${BASE_DIR}/$INVENTORY_FILE
for HOST in $(knife search node "recipes:${ROLE}" -a name 2>/dev/null | grep name | cut -f2 -d':' | sed "s/^[ \t]*//" | sed "s/$/-m.bby/" | sed "s/-m-m/-m/" | sort) ;do
  echo $HOST >>${BASE_DIR}/${INVENTORY_FILE}
  echo $HOST | sed "s/-m.*//" | sed -i '' "/.*${HOST}.*/d" ${BASE_DIR}/hosts.txt
done
echo -e "\n[${ROLE}:vars]\nchef_role=${ROLE}" >>${BASE_DIR}/${INVENTORY_FILE}

INVENTORY_FILE="nighttime_servers"
echo "${green}** ${INVENTORY_FILE}${reset}"
egrep "pcms|prvatg|afpsrccor|afpsrcmrt|afpsrcsas|ugcbch|wflapp" ${BASE_DIR}/hosts.txt > ${BASE_DIR}/${INVENTORY_FILE}
sed -i '' '/.*pcms.*/d' ${BASE_DIR}/hosts.txt
sed -i '' '/.*prvatg.*/d' ${BASE_DIR}/hosts.txt
sed -i '' '/.*afpsrccor.*/d' ${BASE_DIR}/hosts.txt
sed -i '' '/.*afpsrcmrt.*/d' ${BASE_DIR}/hosts.txt
sed -i '' '/.*afpsrcsas.*/d' ${BASE_DIR}/hosts.txt
sed -i '' '/.*ugcbch.*/d' ${BASE_DIR}/hosts.txt
sed -i '' '/.*wflapp.*/d' ${BASE_DIR}/hosts.txt

egrep "wmq10|rdqm10" ${BASE_DIR}/hosts.txt >${BASE_DIR}/mq_servers
sed -i '' '/.*wmq10.*/d' ${BASE_DIR}/hosts.txt
sed -i '' '/.*rdqm10.*/d' ${BASE_DIR}/hosts.txt

egrep "riak|navrpl" ${BASE_DIR}/hosts.txt > ${BASE_DIR}/riak
sed -i '' '/.*riak.*/d' ${BASE_DIR}/hosts.txt
sed -i '' '/.*navrpl.*/d' ${BASE_DIR}/hosts.txt

grep talena ${BASE_DIR}/hosts.txt > ${BASE_DIR}/talena
sed -i '' '/.*talena.*/d' ${BASE_DIR}/hosts.txt

grep cgrndb ${BASE_DIR}/hosts.txt > ${BASE_DIR}/cgraph_db
sed -i '' '/.*cgrndb.*/d' ${BASE_DIR}/hosts.txt

grep smrtdb ${BASE_DIR}/hosts.txt > ${BASE_DIR}/smart_db
sed -i '' '/.*smrtdb.*/d' ${BASE_DIR}/hosts.txt

grep ddsdb ${BASE_DIR}/hosts.txt > ${BASE_DIR}/dds_db
sed -i '' '/.*ddsdb.*/d' ${BASE_DIR}/hosts.txt

grep fildb ${BASE_DIR}/hosts.txt > ${BASE_DIR}/fil_db
sed -i '' '/.*fildb.*/d' ${BASE_DIR}/hosts.txt

grep txndb ${BASE_DIR}/hosts.txt > ${BASE_DIR}/transaction_db
sed -i '' '/.*txndb.*/d' ${BASE_DIR}/hosts.txt

grep vgrdb ${BASE_DIR}/hosts.txt > ${BASE_DIR}/vgraph_db
sed -i '' '/.*vgrdb.*/d' ${BASE_DIR}/hosts.txt

grep orddb ${BASE_DIR}/hosts.txt > ${BASE_DIR}/order_db
sed -i '' '/.*orddb.*/d' ${BASE_DIR}/hosts.txt

grep betadb ${BASE_DIR}/hosts.txt > ${BASE_DIR}/beta_db
sed -i '' '/.*betadb.*/d' ${BASE_DIR}/hosts.txt

grep chatdb ${BASE_DIR}/hosts.txt > ${BASE_DIR}/chat_db
sed -i '' '/.*chatdb.*/d' ${BASE_DIR}/hosts.txt

grep opscdb ${BASE_DIR}/hosts.txt > ${BASE_DIR}/opsc_db
sed -i '' '/.*opscdb.*/d' ${BASE_DIR}/hosts.txt

grep pdgdb ${BASE_DIR}/hosts.txt > ${BASE_DIR}/pdg_db
sed -i '' '/.*pdgdb.*/d' ${BASE_DIR}/hosts.txt

grep gphap ${BASE_DIR}/hosts.txt > ${BASE_DIR}/graphite
sed -i '' '/.*gphap.*/d' ${BASE_DIR}/hosts.txt

grep cgrsrc ${BASE_DIR}/hosts.txt > ${BASE_DIR}/cgraph_search_db
sed -i '' '/.*cgrsrc.*/d' ${BASE_DIR}/hosts.txt

grep mglndb  ${BASE_DIR}/hosts.txt > ${BASE_DIR}/mglndb_db
sed -i '' '/.*mglndb.*/d' ${BASE_DIR}/hosts.txt

grep sfxdb  ${BASE_DIR}/hosts.txt > ${BASE_DIR}/sfxdb_db
sed -i '' '/.*sfxdb.*/d' ${BASE_DIR}/hosts.txt

grep trsdb  ${BASE_DIR}/hosts.txt > ${BASE_DIR}/trsdb_db
sed -i '' '/.*trsdb.*/d' ${BASE_DIR}/hosts.txt

grep bskdb  ${BASE_DIR}/hosts.txt > ${BASE_DIR}/bskdb_db
sed -i '' '/.*bskdb.*/d' ${BASE_DIR}/hosts.txt

echo "${green}** Web Servers${reset}"
egrep "cfpweb10[1,2,3,8,9]|cfpimg101|cfpweb201|appweb10[1,3]|nonweb10[1,2,3]|afpweb101|afpweb201|nonweb20[1,2]|afpimg101" ${BASE_DIR}/hosts.txt > ${BASE_DIR}/web_host_1
egrep "cfpweb1[0,1][4,5,6,7,0]|cfpimg102|cfpweb202|appweb10[2,4]|afpimg102|nonweb10[4,5,6]|nonweb20[3,4]|afpweb102|afpweb202|afpimg102" ${BASE_DIR}/hosts.txt > ${BASE_DIR}/web_host_2
sed -i '' '/.*cfpweb.*/d' ${BASE_DIR}/hosts.txt
sed -i '' '/.*cfpimg.*/d' ${BASE_DIR}/hosts.txt
sed -i '' '/.*appweb.*/d' ${BASE_DIR}/hosts.txt
sed -i '' '/.*nonweb.*/d' ${BASE_DIR}/hosts.txt
sed -i '' '/.*afpweb.*/d' ${BASE_DIR}/hosts.txt
sed -i '' '/.*afpimg.*/d' ${BASE_DIR}/hosts.txt

egrep "web[0-9]{2}[1,5,9]" ${BASE_DIR}/hosts.txt >>${BASE_DIR}/web_host_1
egrep "web[0-9]{2}[2,6,0]" ${BASE_DIR}/hosts.txt >>${BASE_DIR}/web_host_2
egrep "web[0-9]{2}[4,8]" ${BASE_DIR}/hosts.txt >${BASE_DIR}/web_host_4
egrep "web[0-9]{2}[3,7]" ${BASE_DIR}/hosts.txt >${BASE_DIR}/web_host_3
sed -i '' '/.*web[0-9]\{3\}.*/d' ${BASE_DIR}/hosts.txt

##
# various inventory
##
for INVENTORY_FILE in apigee graphite rabbitmq kafka zookeeper tealeaf_capture; do
  echo "${green}** ${INVENTORY_FILE}${reset}"
  rm -f ${BASE_DIR}/${INVENTORY_FILE}
  pushd ~/git/chef/dc-roles/ 1>/dev/null 2>&1; ROLES=$(grep "depends '${INVENTORY_FILE}'" */metadata.rb | cut -f1 -d'/'); popd 1>/dev/null 2>&1
  for ROLE in $ROLES; do
    echo "   ${magenta}${ROLE}${reset}"
    echo -e "[${ROLE}]" >>${BASE_DIR}/${INVENTORY_FILE}
    for HOST in $(knife search node "recipes:${ROLE}" -a name 2>/dev/null | grep name | cut -f2 -d':' | sed "s/^[ \t]*//" | sed "s/$/-m.bby/" | sed "s/-m-m/-m/" | sort) ;do
      echo $HOST >>${BASE_DIR}/${INVENTORY_FILE}
      # echo "      ${yellow}removing ${HOST} from hosts.txt${reset}"
      echo $HOST | sed "s/-m.*//" | sed -i '' "/.*${HOST}.*/d" ${BASE_DIR}/hosts.txt
    done
    echo -e "\n[${ROLE}:vars]\nchef_role=${ROLE}\n\n" >>${BASE_DIR}/${INVENTORY_FILE}
  done
done

##
# 101-104
##
echo "${green}** 101-104 Various${reset}"
egrep "[0-9]{2}[1,5,9]" ${BASE_DIR}/hosts.txt > ${BASE_DIR}/101_hosts
sed -i '' '/.*[0-9]\{2\}[1,5,9].*/d' ${BASE_DIR}/hosts.txt

egrep "[0-9]{2}[2,6,0]" ${BASE_DIR}/hosts.txt > ${BASE_DIR}/102_hosts
sed -i '' '/.*[0-9]\{2\}[2,6,0].*/d' ${BASE_DIR}/hosts.txt

egrep "[0-9]{2}[3,7]" ${BASE_DIR}/hosts.txt > ${BASE_DIR}/103_hosts
sed -i '' '/.*[0-9]\{2\}[3,7].*/d' ${BASE_DIR}/hosts.txt

egrep "[0-9]{2}[4,8]" ${BASE_DIR}/hosts.txt > ${BASE_DIR}/104_hosts
sed -i '' '/.*[0-9]\{2\}[4,8].*/d' ${BASE_DIR}/hosts.txt

##
# separate generic_tomcat from the rest of 101-104
##
echo -e "${green}** generic-tomcat${reset}"
knife search node "recipes:dc-generic-tomcat-role" -a name 2>/dev/null | grep name | cut -f2 -d':' | sed "s/^[ \t]*//" | sort >${BASE_DIR}/generic_tomcat.txt
sed -i '' -e "s/$/-m.bby/" -e "s/-m-m/-m/" ${BASE_DIR}/generic_tomcat.txt

for num in $(seq 101 104); do
  echo '[dc-generic-tomcat-role]' >${BASE_DIR}/${num}_generic_tomcat
done

egrep "[0-9]{2}[1,5,9]" ${BASE_DIR}/generic_tomcat.txt >>${BASE_DIR}/101_generic_tomcat
sed -i '' '/.*[0-9]\{2\}[1,5,9].*/d' ${BASE_DIR}/generic_tomcat.txt

egrep "[0-9]{2}[2,6,0]" ${BASE_DIR}/generic_tomcat.txt >>${BASE_DIR}/102_generic_tomcat
sed -i '' '/.*[0-9]\{2\}[2,6,0].*/d' ${BASE_DIR}/generic_tomcat.txt

egrep "[0-9]{2}[3,7]" ${BASE_DIR}/generic_tomcat.txt >>${BASE_DIR}/103_generic_tomcat
sed -i '' '/.*[0-9]\{2\}[3,7].*/d' ${BASE_DIR}/generic_tomcat.txt

egrep "[0-9]{2}[4,8]" ${BASE_DIR}/generic_tomcat.txt >>${BASE_DIR}/104_generic_tomcat
sed -i '' '/.*[0-9]\{2\}[4,8].*/d' ${BASE_DIR}/generic_tomcat.txt

for num in $(seq 101 104); do
  echo -e "\n[dc-generic-tomcat-role:vars]\nchef_role=dc-generic-tomcat-role" >>${BASE_DIR}/${num}_generic_tomcat
done

pushd ~/git/chef/dc-roles/ 1>/dev/null 2>&1
ROLES=$(grep "depends 'dc-generic-tomcat-role" */metadata.rb | cut -f1 -d'/')
OLD_TOMCAT_ROLES=$(grep "depends 'dc_tomcat" */metadata.rb | cut -f1 -d'/' | \
  grep -v dc-af-search-bustool-role | \
  grep -v dc-expresslane-secure-gateway-role | \
  grep -v dc-workflow-role \
)
popd 1>/dev/null 2>&1

for ROLE in $ROLES; do
  echo "   ${magenta}${ROLE}${reset}"
  knife search node "recipes:${ROLE}" -a name 2>/dev/null | grep name | cut -f2 -d':' | sed "s/^[ \t]*//" | sort >${BASE_DIR}/${ROLE}
  sed -i '' -e "s/$/-m.bby/" -e "s/-m-m/-m/" ${BASE_DIR}/${ROLE}

  echo -e "\n[${ROLE}]" >>${BASE_DIR}/101_generic_tomcat
  egrep "[0-9]{2}[1,5,9]" ${BASE_DIR}/${ROLE} >>${BASE_DIR}/101_generic_tomcat
  sed -i '' '/.*[0-9]\{2\}[1,5,9].*/d' ${BASE_DIR}/${ROLE}
  echo -e "\n[${ROLE}:vars]\nchef_role=${ROLE}" >>${BASE_DIR}/101_generic_tomcat

  echo -e "\n[${ROLE}]" >>${BASE_DIR}/102_generic_tomcat
  egrep "[0-9]{2}[2,6,0]" ${BASE_DIR}/${ROLE} >>${BASE_DIR}/102_generic_tomcat
  sed -i '' '/.*[0-9]\{2\}[2,6,0].*/d' ${BASE_DIR}/${ROLE}
  echo -e "\n[${ROLE}:vars]\nchef_role=${ROLE}" >>${BASE_DIR}/102_generic_tomcat

  echo -e "\n[${ROLE}]" >>${BASE_DIR}/103_generic_tomcat
  egrep "[0-9]{2}[3,7]" ${BASE_DIR}/${ROLE} >>${BASE_DIR}/103_generic_tomcat
  sed -i '' '/.*[0-9]\{2\}[3,7].*/d' ${BASE_DIR}/${ROLE}
  echo -e "\n[${ROLE}:vars]\nchef_role=${ROLE}" >>${BASE_DIR}/103_generic_tomcat

  echo -e "\n[${ROLE}]" >>${BASE_DIR}/104_generic_tomcat
  egrep "[0-9]{2}[4,8]" ${BASE_DIR}/${ROLE} >>${BASE_DIR}/104_generic_tomcat
  sed -i '' '/.*[0-9]\{2\}[4,8].*/d' ${BASE_DIR}/${ROLE}
  echo -e "\n[${ROLE}:vars]\nchef_role=${ROLE}" >>${BASE_DIR}/104_generic_tomcat
done

for num in $(seq 101 104); do
  for host in $(grep "\-m.bby" ${BASE_DIR}/${num}_generic_tomcat); do
    sed -i '' "/${host}/d" ${BASE_DIR}/${num}_hosts
  done
done

##
# separate generic_nodejs from the rest of 101-104
##
echo -e "${green}** generic-nodejs${reset}"
knife search node "recipes:dc-generic-nodejs-role" -a name 2>/dev/null | grep name | cut -f2 -d':' | sed "s/^[ \t]*//" | sort >${BASE_DIR}/generic_nodejs.txt
sed -i '' -e "s/$/-m.bby/" -e "s/-m-m/-m/" ${BASE_DIR}/generic_nodejs.txt

for num in $(seq 101 104); do
  echo '[dc-generic-nodejs-role]' >${BASE_DIR}/${num}_generic_nodejs
done

egrep "[0-9]{2}[1,5,9]" ${BASE_DIR}/generic_nodejs.txt >>${BASE_DIR}/101_generic_nodejs
sed -i '' '/.*[0-9]\{2\}[1,5,9].*/d' ${BASE_DIR}/generic_nodejs.txt

egrep "[0-9]{2}[2,6,0]" ${BASE_DIR}/generic_nodejs.txt >>${BASE_DIR}/102_generic_nodejs
sed -i '' '/.*[0-9]\{2\}[2,6,0].*/d' ${BASE_DIR}/generic_nodejs.txt

egrep "[0-9]{2}[3,7]" ${BASE_DIR}/generic_nodejs.txt >>${BASE_DIR}/103_generic_nodejs
sed -i '' '/.*[0-9]\{2\}[3,7].*/d' ${BASE_DIR}/generic_nodejs.txt

egrep "[0-9]{2}[4,8]" ${BASE_DIR}/generic_nodejs.txt >>${BASE_DIR}/104_generic_nodejs
sed -i '' '/.*[0-9]\{2\}[4,8].*/d' ${BASE_DIR}/generic_nodejs.txt

for num in $(seq 101 104); do
  echo -e "\n[dc-generic-nodejs-role:vars]\nchef_role=dc-generic-nodejs-role" >>${BASE_DIR}/${num}_generic_nodejs
done

pushd ~/git/chef/dc-roles/ 1>/dev/null 2>&1; ROLES=$(grep "depends 'dc-generic-nodejs-role" */metadata.rb | cut -f1 -d'/'); popd 1>/dev/null 2>&1
for ROLE in $ROLES; do
  echo "Handling ${ROLE} as generic-nodejs dependant"
  knife search node "recipes:${ROLE}" -a name 2>/dev/null | grep name | cut -f2 -d':' | sed "s/^[ \t]*//" | sort >${BASE_DIR}/${ROLE}
  sed -i '' -e "s/$/-m.bby/" -e "s/-m-m/-m/" ${BASE_DIR}/${ROLE}

  echo -e "\n[${ROLE}]" >>${BASE_DIR}/101_generic_nodejs
  egrep "[0-9]{2}[1,5,9]" ${BASE_DIR}/${ROLE} >>${BASE_DIR}/101_generic_nodejs
  sed -i '' '/.*[0-9]\{2\}[1,5,9].*/d' ${BASE_DIR}/${ROLE}
  echo -e "\n[${ROLE}:vars]\nchef_role=${ROLE}" >>${BASE_DIR}/101_generic_nodejs

  echo -e "\n[${ROLE}]" >>${BASE_DIR}/102_generic_nodejs
  egrep "[0-9]{2}[2,6,0]" ${BASE_DIR}/${ROLE} >>${BASE_DIR}/102_generic_nodejs
  sed -i '' '/.*[0-9]\{2\}[2,6,0].*/d' ${BASE_DIR}/${ROLE}
  echo -e "\n[${ROLE}:vars]\nchef_role=${ROLE}" >>${BASE_DIR}/102_generic_nodejs

  echo -e "\n[${ROLE}]" >>${BASE_DIR}/103_generic_nodejs
  egrep "[0-9]{2}[3,7]" ${BASE_DIR}/${ROLE} >>${BASE_DIR}/103_generic_nodejs
  sed -i '' '/.*[0-9]\{2\}[3,7].*/d' ${BASE_DIR}/${ROLE}
  echo -e "\n[${ROLE}:vars]\nchef_role=${ROLE}" >>${BASE_DIR}/103_generic_nodejs

  echo -e "\n[${ROLE}]" >>${BASE_DIR}/104_generic_nodejs
  egrep "[0-9]{2}[4,8]" ${BASE_DIR}/${ROLE} >>${BASE_DIR}/104_generic_nodejs
  sed -i '' '/.*[0-9]\{2\}[4,8].*/d' ${BASE_DIR}/${ROLE}
  echo -e "\n[${ROLE}:vars]\nchef_role=${ROLE}" >>${BASE_DIR}/104_generic_nodejs
done

for num in $(seq 101 104); do
  for host in $(grep "\-m.bby" ${BASE_DIR}/${num}_generic_nodejs); do
    sed -i '' "/${host}/d" ${BASE_DIR}/${num}_hosts
  done
done

##
# Legacy Tomcat
##
INVENTORY_FILE="tomcat_legacy"
echo "${green}** ${INVENTORY_FILE}${reset}"
rm -f ${BASE_DIR}/${INVENTORY_FILE}
for ROLE in $OLD_TOMCAT_ROLES; do
  echo "   ${magenta}${ROLE}${reset}"
  echo -e "[${ROLE}]" >>${BASE_DIR}/tomcat_legacy
  knife search node "recipes:${ROLE}" -a name 2>/dev/null | grep name | cut -f2 -d':' | sed "s/^[ \t]*//" | sed "s/$/-m.bby/" | sed "s/-m-m/-m/" | sort >>${BASE_DIR}/${INVENTORY_FILE}
  echo -e "\n[${ROLE}:vars]\nchef_role=${ROLE}\n" >>${BASE_DIR}/${INVENTORY_FILE}
done


# jboss hosts have their own inventory file
for x in `seq 101 104`; do
  sed -i '' '/.*dataapi.*/d' ${BASE_DIR}/${x}_hosts
  sed -i '' '/.*atg.*/d' ${BASE_DIR}/${x}_hosts
  sed -i '' '/^[Pp][Dd][Ww].*/d' ${BASE_DIR}/${x}_hosts # ** Remove as appropriate
done

# Remove Windows
sed -i '' '/^pdw.*/d' ${BASE_DIR}/jumphosts

mv ${BASE_DIR}/hosts.txt ${BASE_DIR}/leftover.txt

echo "${green}Delete 0-sized source files${reset}"
find ${BASE_DIR} -type f -size 0 -delete

echo "${green}Removing NoSQL source files${reset}"
find ${BASE_DIR} -type f -name "*_db*" -delete
rm -f ${BASE_DIR}/riak
rm -f ${BASE_DIR}/talena

echo "${green}Removing IBMMQ source files${reset}"
rm -f ${BASE_DIR}/mq_servers
